#include <stdio.h>

#include "simz80.h"
#include "zx81rom.h"
#include "stdint.h"
#include <string.h>

/* address of the pointer to the beginning of the display file */
#define D_FILE 0x400c

/* the z80 state */
static struct z80 z80;

/* the memory */
static BYTE memory[ 65536 ];

/* fetches an opcode from memory */
BYTE z80_fetch( struct z80* z80, WORD a )
{
  return memory[ a ];
}

/* reads from memory */
BYTE z80_read( struct z80* z80, WORD a )
{
  return memory[ a ];
}

/* writes to memory */
void z80_write( struct z80* z80, WORD a, BYTE b )
{
  /* don't write to rom */
  if ( a >= 0x4000 )
  {
    memory[ a ] = b;
  }
}

/* reads from a port */
BYTE z80_in( struct z80* z80, WORD a )
{
  (void)z80;
  (void)a;
}

/* writes to a port */
void z80_out( struct z80* z80, WORD a, BYTE b )
{
  (void)z80;
  (void)a;
  (void)b;
}

static void setup_emulation( void )
{
  memset( &z80, 0, sizeof( z80 ) );
  
  /* load rom with ghosting at 0x2000 */
  memcpy( memory + 0x0000, rom, 0x2000 );
  memcpy( memory + 0x2000, rom, 0x2000 );
  
  /* patch DISPLAY-5 to a return */
  memory[ 0x02b5 + 0x0000 ] = 0xc9;
  memory[ 0x02b5 + 0x2000 ] = 0xc9;
  
  /* setup the registers */
  z80.pc  = 0;
  z80.iff = 0;
  z80.af_sel = z80.regs_sel = 0;
}

int main( int argc, char *argv[] )
{
  /* a counter do dump the program counter from time to time */
  int count;
  /* initialize the state */
  setup_emulation();
  printf( "ZX81 Emulator\n\n");
  
  /* emulate! */
  for ( count = 0;; count++ )
	{
    z80_step( &z80 );
    
    if ( ( count & 0xff ) == 0 )
    {
      printf( "%04x\n", z80.pc );
    }
	}

  /* we never get here... */
  return 0;
}
