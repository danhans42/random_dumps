// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
// 
// Standard kinda fare though, no explicit or implied warranty.
// Any issues arising from the use of this software are your own.
// 
// https://github.com/JonathanDotCel
//

#ifndef  MAINC
#define MAINC

// variadic logging
#include <stdarg.h>
#include "main.h"

//
// Includes
//

#include "littlelibc.h"
#include "utility.h"
#include "drawing.h"
#include "pads.h"
#include "ttyredirect.h"
#include "config.h"
#include "gpu.h"
#include "sio.c"

int mute;


//
// Protos
//

void InitSPU();
void DoStuff();



int main(){
	mute = 0x0;
	//ResetEntryInt();
	ExitCritical();

	// Clear the text buffer
	InitBuffer();
	InitSPU();	
	// Init the pads after the GPU so there are no active
	// interrupts and we get one frame of visual confirmation.
	
	InitGPU();

	InitPads();

	// Enable this if you're not inheriting a TTY redirect device from Unirom, n00bROM, etc
	//InstallTTY();
	//NewPrintf( "You can now use NewPrintf() functions!\n" );	


	// Main loop
	while ( 1 ){

		MonitorPads();

		ClearScreenText();

		C64Border();


		Blah( "\n\n  ========================= PSX-I2S ========================= \n");
		if (mute==0) Blah("\n\n\n   Ext I2S Audio Enabled\n"); 
		else Blah("\n\n\n   Ext I2S Audio Muted\n");


		DoStuff();

		//SIOSendString("Fuckers!!!!!!!");
	/*	if (BufferEmpty() > 0 ) {
			Blah( " No Data\n");
		}
		else {
				Blah( " Data\n");
				c0 = ReadByte();
		} */


		Draw();

	}

}


void InitSPU() {

	// cheers skitchin :)

	// SPU Main Volume Left + Right
	*(volatile unsigned short *)0x1F801D80 = 0x3ffe;
	*(volatile unsigned short *)0x1F801D82 = 0x3ffe;

  	// External Audio Input Volume
    *(volatile unsigned short *)0x1F801DB4 = 0x3fff;
	*(volatile unsigned short *)0x1F801DB6 = 0x3fff;

    // SPU Control register
	*(volatile unsigned short *)0x1F801DAA = 0xc002; // External Audio Enable

}


void DoStuff(){

	int pixel = 0, x=0, y=0;

	if ( Released( PADRup ) ){
		// restart via bios
		goto *(ulong*)0xBFC00000;
	}


	if ( Released( PADRdown ) ){
		// restart via bios
		*(volatile unsigned short *)0x1F801DAA = 0xc002; // External Audio Enable
		mute=0;
	}

	if ( Released( PADRright ) ){
		// restart via bios
		*(volatile unsigned short *)0x1F801DAA = 0xc000; // External Audio Disable
		mute=1;
	}



     
}


#endif // ! MAINC

