# Purpose
This directory contains mips-only code, targeting the PSX CPU. It contains various tests and rewrites.

# License
This subdirectory is fully independent code that doesn't link against the rest of the project. Therefore, this subdirectory is covered by the MIT license, and can be used independently from the rest of the project. It's based heavily on Nicolas Noble's work on PCSX-redux.
