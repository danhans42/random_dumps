

//
//  BIG FLASHING MEGA WARNING
//
//  While we're grabbing data from SIO, it might be overwriting
//  our own code, variables, etc
//  Just keep it in mind!
//

#include "sio.h"

#include "config.h"
#include "drawing.h"

#include "littlelibc.h"
#include "main.h"
#include "utility.h"
#include "hwregs.h"
#include "pads.h"


static void InitSIO(int inBaud, int useInterrupts);

// abort after this many cycles without fresh data
#define WAIT_FINISH_TRIGGER 500000

// Did we switch to > 115200 baud?
static int sioFastMode = 0;
static int sioDebugDisable = 0;

// Using interrupts, or polling it?
static int sioUsingInterrupts = 0;

// little wait counter and prevents the compiler removing empy loops
static ulong optWait = 0;

static ulong checksum_calced = 0;
static ulong protocol_version = 1;


// Call it as often as you like
static void InitSIO(int inBaud, int useInterrupts) {
    // rough sony libs equivalent
    //_sio_control( 1, 3, inBaud );
    //_sio_control(1,2, MR_SB_11 | MR_CHLEN_8 | MR_BR_16 );
    //_sio_control( 1, 1, CR_RXIEN | CR_RXEN | CR_TXEN );
    // Sio1Callback( ReadSIO );

    // Clear all the fings.
    pSIOCONTROL = CR_INTRST;

    // Baud
    pSIOBAUD = (0x1FA400 / inBaud);
    // Using actual CPU clock frequency divisions would yield the following but not work:

    // pSIOBAUD = ( 0x204CC000 / inBaud );

    // 8 bit, 1 stop bit, no parity, 16x mul
    pSIOMODE = MR_SB_11 | MR_CHLEN_8 | MR_BR_16;

    // Appears to be no harm leaving the RXInterruptEnable on even if we're polling

    pSIOCONTROL = CR_RXEN | CR_TXEN;

    if (useInterrupts) {
        // Removed it :)
        sioUsingInterrupts = 1;
    }
}

// Normal SIO
void NormalSIO() {
    InitSIO(115200, sioUsingInterrupts);
    sioFastMode = 0;
}

// Half a meg is a bit more stable
void FastSIO() {
    InitSIO(1036800, sioUsingInterrupts);
    sioFastMode = 1;
}

void DisableSIO() { sioDebugDisable = 1; }

char SioInFastMode() { return sioFastMode; }

// Anything in the SIO buffer?
// (RXRDY is a misnomer, means there's stuff in the buffer)
static inline int BufferEmpty() { return ((pSIOSTATUS & SR_RXRDY) == 0); }

// Same as BufferEmpty, but saves one instruction
static inline int SomethingInBuffer() { return ((pSIOSTATUS & SR_RXRDY)); }

// https://www.youtube.com/watch?v=YklZBA9UBjc
static inline void Ack() { pSIOCONTROL |= CR_ERRRST; }

// Not worth changing without a real good reason.
static inline void SIOWait() { Delay(10); }

// Send extra response bytes during interrupts
static void SendChar(char inChar) {
    // LIBSIO equivalent
    // while((_sio_control(0,0,0)&(SR_TXU|SR_TXRDY))!=(SR_TXU|SR_TXRDY));
    //_sio_control(1,4,c);

    unsigned short waitFlag = SR_TXU | SR_TXRDY;

    // Small timing delay since we're on fixed hardwarre
    SIOWait();

    // seems you can completely jam up the SIO hardware
    // so let's not wait around forever.
    optWait = 0;
    while (((pSIOSTATUS & waitFlag) != waitFlag) && optWait < 20000) {
        optWait++;
    }
    pSIODATA = inChar;
}

void SendUlong( ulong inVal ){

    SendChar((inVal & 0x000000FF) >> 0);
    SendChar((inVal & 0x0000FF00) >> 8);
    SendChar((inVal & 0x00FF0000) >> 16);
    SendChar((inVal & 0xFF000000) >> 24);

}

void SIOSendString(const char *inChar) {
    int offset = 0;

    while (inChar[offset] != 0) {
        SendChar(inChar[offset]);
        offset++;
    }
}

// BUG: ?
// Ack() May be useless if performed before lw pSIODATA
// (meaning more Ack()s required after?)
static inline uchar ReadByte() {
    while (BufferEmpty()) {
        optWait++;
    }

    Ack();

    return pSIODATA;
}

// shift 4 bytes into a 32 bit int
// No latching required to *read* extra data
// during the SIO interrupt
static inline ulong Read32() {
    ulong returnVal = 0;

    returnVal |= ReadByte();
    returnVal |= ReadByte() << 8;
    returnVal |= ReadByte() << 16;
    returnVal |= ReadByte() << 24;

    return returnVal;
}

// And negotiate protocol version
static inline ulong Respond_OKAY() { 
    
    // Does this version of nops know protocol V2?
    SIOSendString("OKV2");

    int waitTimeout = 0;
    int charsRead = 0;

    // For now, we'll have to timeout as this wasn't
    // implemented in older versions. Could potentially
    // be removed in a couple of versions.
    while( 1 ){

        
        if ( SomethingInBuffer() ){
            // lol there's definitely a better way :D
            // e.g. (buffer >> 8 | char << 24)
            *(char *)(SIO_SPAD) = *(char *)(SIO_SPAD + 1);
            *(char *)(SIO_SPAD + 1) = *(char *)(SIO_SPAD + 2);
            *(char *)(SIO_SPAD + 2) = *(char *)(SIO_SPAD + 3);
            *(char *)(SIO_SPAD + 3) = ReadByte();
            Ack();
        }

        // Did nops confirm that it can speak V2?
        if ( NewStrncmp( (char*)SIO_SPAD, "UPV2", 4 ) == 0 ){
            protocol_version = 2;            
            break;
        }

        // Smaller than nop's "no data back" timeout
        // which, at the time of writing, infinite.
        if ( waitTimeout++ >= 50000 )
            break;

    }
    
    SIOSendString("OKAY"); 

}

static void ReadSIO();

void PollSIO() {
    if (!sioUsingInterrupts) {
        // sio_checkincoming();
        ReadSIO();
    }
}

static inline void Bailout() { 

    // Log it?

    Reboot();
    
}




#pragma GCC push options
#pragma GCC optimize("-O0")
static int ReadStreamV2( ulong writeAddr, ulong writeEnd, ulong checksum_expected ){

    
    ulong waitCounter = 0;
    ulong bytesRead = 0;
    ulong chunkChecksum = 0;
    ulong lastKnownWriteAddr = writeAddr;   // e.g. if we skip bytes, we know where to go back to    
    
    // for testing
    ulong chunkCountModulo = 0;
    checksum_calced = 0;    // e.g. the entire binary

    while (1) {

        if (SomethingInBuffer()) {

            uchar c = ReadByte();
            *(volatile uchar *)(writeAddr) = c;
            writeAddr++;
            waitCounter = 0;                
            chunkChecksum += c;
            bytesRead++;
            
            if ( bytesRead % 2048 == 0 || (writeAddr == writeEnd) ){  

                if ( protocol_version == 1 ){

                    checksum_calced += chunkChecksum;

                } else 
                if ( protocol_version == 2 ){

                    // request and read back the checksum
                    SIOSendString("CHEK");
                    ulong expectedChunkChecksum = Read32();
                    
                    if ( expectedChunkChecksum == chunkChecksum ){
                        SIOSendString( "MORE" );
                        checksum_calced += chunkChecksum;
                        lastKnownWriteAddr = writeAddr;
                    } else {
                        SIOSendString("ERR!");
                        writeAddr = lastKnownWriteAddr;
                    }

                }

                chunkChecksum = 0;
                
            } // chunk

        } // somethingInBuffer

        waitCounter++;

        if ( waitCounter == WAIT_FINISH_TRIGGER ){
            return 0;
        }

        if (            
            checksum_expected != 0 
            && (checksum_calced == checksum_expected) 
            && (writeAddr == writeEnd)
        ){             
            return 1;
        }  
        
    } // while


}
#pragma GCC pop options


    static void ChecksumError( ulong checksum_expected ){
        
        Blah("\n        Checksum error; check your cables!\n        Expected: %x Calced: %x\n", checksum_expected, checksum_calced);
        HoldMessage();
        return;
        
    }



// Our actual read() function
// Bear in mind that the function may be polled or an interrupt.
// In polled mode (default) we only have 8 bytes of buffer before
// going into a tight loop to read the rest.
// shuffles input till a command is found:
// So [noise][4 byte command][optional cr\lf][noise]
/*static void ReadSIO() {
    // General purpose vars
    unsigned char c;
    int waitCounter = 0;
    int offset = 0;
    int val = 0;

    // incoming / outgoing data
    ulong jumpAddr = 0;
    ulong writeAddr = 0;
    ulong size = 0;
    ulong nullVal = 0;
    ulong readAddr = 0;

    // checksums
    unsigned long checksum_expected = 0;
    unsigned long checksum_calced = 0;
    unsigned long protocol_version = 0;
    
    // For making a call() vs a jmp
    void (*foo)(void);

    // for testing the debug driver
    if (sioDebugDisable) {
        return;
    }

    // Anything in the RX fifo?
    if (BufferEmpty()) {
        return;
    }

    // Echo back untill we reach a valid sequence
    c = ReadByte();
    Ack();
    SendChar(c);

    // Just need 4 bytes of buffer as the SIO
    // only has 8 bytes anyway
    // we're getting one char per frame
    // untill entering a dedicated loop below
    *(char *)(SIO_SPAD) = *(char *)(SIO_SPAD + 1);
    *(char *)(SIO_SPAD + 1) = *(char *)(SIO_SPAD + 2);
    *(char *)(SIO_SPAD + 2) = *(char *)(SIO_SPAD + 3);
    *(char *)(SIO_SPAD + 3) = c;
    

    // STOP!
    // Beyond this point, anything in RAM is fair game
    // we're not executing from the ROM either!

    // You can get some of these smaller commands via
    // echo REST>COM8, etc in windows
    // or the linux equiv

    // "FAST" - Negotiate fast mode
    if (pSPAD == 0x54534146) {
        FastSIO();
    }

    // "SLOW" - Negotiate slow mode
    if (pSPAD == 0x574F4C53) {
        NormalSIO();
    }

    // "REST" - Reset
    if (pSPAD == 0x54534552) {

        // Respond_OKAY();

        pSIOCONTROL = CR_INTRST;
        Bailout();
    }

    // "BOOT" - Load a game
    if (pSPAD == 0x424FF454) {
        CDLoad(0);        
    }

    // "HEXE" - HEX EDITOR
    if (pSPAD == 0x45584548) {
        DoMenu_Hex();
    }

    // "CALL" - Call a function (and return)
    if (pSPAD == 0x4C4C4143) {
        Respond_OKAY();

        jumpAddr = Read32();

        foo = (void (*)(void))jumpAddr;
        foo();
    }

    // "JUMP" - Jump to address
    if (pSPAD == 0x504D554A) {
        Respond_OKAY();

        jumpAddr = Read32();

        UnloadMe();
        goto *(ulong *)jumpAddr;
    }
    
    // "SBIN" - Send BIN.
    if (pSPAD == 0x4E494253) {
        ulong writeEnd = 0;

        ClearTextBuffer();
        Blah("\n\n\n\n\n\n        Downloading .BIN...\n");
        ClearAndDraw();

        EnterCritical();

        Respond_OKAY();

        // Grab some meta data...
        writeAddr = Read32();
        size = Read32();
        checksum_expected = Read32();

        //waitCounter = 0;
        writeEnd = writeAddr + size;
        
        int returnVal = ReadStreamV2( writeAddr, writeEnd, checksum_expected );

        ExitCritical();
        Ack();

        if ( !returnVal ){            
            ChecksumError( checksum_expected );
        }
        
        return;
        
    }  // SEND BIN

    // "DUMP" - Dump some memory
    // Single bytes only as the mips architecture freaks out with unaligned reads
    if (pSPAD == 0x504D5544) {

        // Say hi to NoPS
        Respond_OKAY();

        ClearTextBuffer();
        Blah("\n\n\n\n\n\n        Dumping...\n");
        ClearAndDraw();

        readAddr = Read32();
        size = Read32();
        
        checksum_calced = 0;

        ulong numSent = 0;

        
        for (offset = readAddr; offset < readAddr + size; offset++) {
            c = *(uchar *)offset;
            SendChar(c);
            checksum_calced += c;

            // V2: Stabilises higher speed transfers
            numSent++;
            if ( numSent % 2048 == 0 ){
                ulong blah = Read32();
            }

        }

        // SendInt or SendLong function looking good right about now.
        //SendChar((checksum_calced & 0x000000FF) >> 0);
        //SendChar((checksum_calced & 0x0000FF00) >> 8);
        //SendChar((checksum_calced & 0x00FF0000) >> 16);
        //SendChar((checksum_calced & 0xFF000000) >> 24);
        SendUlong( checksum_calced );

        return;

    }

    // HEXD - hex dump
    if (pSPAD == 0x44584548) {
        Respond_OKAY();

        readAddr = Read32();
        size = Read32();

        for (offset = readAddr; offset < readAddr + size; offset++) {
            c = *(uchar *)offset;
            SendChar(c);
        }
    }

    //"DEBG" - Debug 
    if (pSPAD == 0x47424544) {
        Respond_OKAY();
        
        InstallKDebug();
        
    }


    
    // "SROM" - Send ROM
    if (pSPAD == 0x4D4F5253) {
        
        ulong writeEnd = 0;

        ClearTextBuffer();
        Blah("\n\n\n\n\n\n        Detecting EEPROM...\n\n");
        ClearAndDraw();

        EnterCritical();

        Respond_OKAY();

        writeAddr = GPBUFFER;
        size = Read32();
        checksum_expected = Read32();

        writeEnd = writeAddr + size;

        DetectEEPROM();
        IdentifyEEPROM();
        
        // use cart type rather than EEPROM ID to allow fututre flashing to SRAM
        if ( eeprom_carttype == CART_ERROR ){
            SIOSendString("NONE");
            Bailout();
        }

        if (eeprom_size == 0) {
            SIOSendString("UNKN");
            Bailout();            
        }

        if (eeprom_size < size) {
            SIOSendString("NOPE");
            Bailout();
        }

        DisplayEEPROMIDs();
        DisplayEEPROMInfo();
        Blah("        \n        Requesting Data...\n");
        ClearAndDraw();

        SIOSendString("FITS");
        
        ulong bytesRead = 0;


        int readVal = ReadStreamV2( writeAddr, writeEnd, checksum_expected );


        ExitCritical();
        Ack();

        if ( readVal ){

            Blah("\n        Checksum's fine...\n");
            Blah("\n        Starting Write...\n\n");
            ClearAndDraw();

            FlashROM(GPBUFFER, size);
            
        } else {            
            ChecksumError( checksum_expected );
            return;
        }

        

    }



    // "SEXE" - Send Exe
    if (pSPAD == 0x45584553) {

        ulong writeEnd = 0;

        ClearTextBuffer();
        Blah("\n\n\n\n\n\n        Downloading .EXE...\n");
        ClearAndDraw();

        EnterCritical();

        Respond_OKAY();

        // Header's unused, but read it in for now.
        for (waitCounter = 0; waitCounter < 2048; waitCounter++) {
            ReadByte();
        }

        // Grab some meta data
        jumpAddr = Read32();
        writeAddr = Read32();
        size = Read32();
        checksum_expected = Read32();

        //#if DEBUG_STUFF
        *(ulong *)0x1F800200 = jumpAddr;
        *(ulong *)0x1F800204 = writeAddr;
        *(ulong *)0x1F800208 = size;
        *(ulong *)0x1F80020C = checksum_expected;
        //#endif
        
        writeEnd = writeAddr + size;

        int returnVal = ReadStreamV2( writeAddr, writeEnd, checksum_expected );
        
        if ( returnVal ){
            
            ExitCritical();            
            UnloadMe();
            //goto *(ulong *)jumpAddr;
            ((int(*)(int, char **))jumpAddr)(0, NULL);

        } else {
            ExitCritical();
            Ack();
            ChecksumError( checksum_expected );
            return;
        }

    }

    // Need a way to enter the SPI test
    // mode without having a pad in
    // (less noise for the logic analyser)
    // "TEST" - SPI Test screen
    if ( pSPAD == 0x54534554 ){        
        SIOSendString("DONE");
        SPITestScreen();        
    }

    // debug stuff

    // "HALT" - HALT
    if ( pSPAD == 0x544C4148 ){
        //SIOSendString("ONLY");  // only avail in debug mode

        Ack();
        InstallKDebug();
        volatile ulong x = (ulong)&KDHalt;
        ((ulong(*)(void))x)();

    }
    // "CONT" - CONTINUE FROM HALT
    if ( pSPAD == 0x544E4F43 ){
        SIOSendString("ONLY");   
    }    
    
    // HKRD - Hook Read
    if ( pSPAD == 0x44524B48 ){
        SIOSendString( "ONLY" );
    }

    // HKWR - Hook Write
    if ( pSPAD == 0x52574B48 ){
        SIOSendString( "ONLY" );
    }

    // HKEX - Hook Exec
    if ( pSPAD == 0x58454B48 ){
        SIOSendString( "ONLY" );
    }

    // easter egg    
    if (pSPAD == 0x544F4353) {
        UnknownFlag1();        
    }

    if (pSPAD == 0x444E414C) {
        UnknownFlag2();
    }

    // MCUP - memorycard upload
    if ( pSPAD == 0x5055434D ){
        
        if ( IsCardScreenActive() ){
            QuickBlah( "\n\n\n\n\n\n        Exit the card screen first!");
            HoldMessage();
            SIOSendString( "HECK" );
            return;
        }
                
        QuickBlah("\n\n\n\n\n\n        Downloading .mcr...\n");
        
        EnterCritical();

        Respond_OKAY(); // and init V2

        // do this after the response (it's timed)
        
        ulong buffer = GPBUFFER;
        ulong whichCard = Read32();
        size = Read32(); // inBytes
        checksum_expected = Read32();

        ulong bufferEnd = buffer + size;

        int returnVal = ReadStreamV2( buffer, bufferEnd, checksum_expected );

        ExitCritical();
        
        if ( !returnVal ){
            ChecksumError( checksum_expected );
            SIOSendString( "HECK" );
            Ack();
            return;
        }

        
        if ( !IsCardPresent( whichCard ) ){
            //ClearTextBuffer();
            QuickBlah_Hold("\n\n\n\n\n\n        Card not inserted!\n");    
            //HoldMessage();
            goto writeDone;
        }


        ulong numSectors = size / 0x80;
        if ( size % 0x80 > 0 ) numSectors++;

        //WriteMemCard( whichCard, (char*)writeAddr, 0, numSectors, 1 );
        for( int i = 0; i < numSectors; i++ ){
            ulong write = buffer + ( i * CARDSECTOR );
            CardWriteSummary * cws = RawWriteCardSector( whichCard, (char*)write, i, 1, MC_NORELOCATE );
                        
            if ( !cws->success ){
                
                QuickBlah_Hold("\n\n\n\n\n\n        Error writing sector %d of %d...\n", i, numSectors);
                
                goto writeDone;
            }
            
            if ( i % 16 == 0 ){                
                NewPrintf( "Writing sector %d of %d (%d%%)\n", i, numSectors, ( i * 100 ) / numSectors );
                QuickBlah("\n\n\n\n\n\n        Writing sector %d of %d...\n", i, numSectors);                
            }
        }

        writeDone:

        InvalidateCards();
        
        Ack();
        return;

    }

    // MCDN - memorycard download
    if ( pSPAD == 0x4E44434D ){
        
        if ( IsCardScreenActive() ){
            QuickBlah( "\n\n\n\n\n\n        Exit the card screen first!");
            HoldMessage();
            SIOSendString( "HECK" );
            return;
        }
        
        
        EnterCritical();

        Respond_OKAY(); //and init V2

        ulong whichCard = Read32();
        
        ulong numSectors = CARDSIZE / CARDSECTOR;
       
        ExitCritical();
        
        for( int i = 0; i < numSectors; i++ ){

            char * dest = (char*)(GPBUFFER + (i*CARDSECTOR));

            CardReadSummary * crs = RawReadCardSector( whichCard, dest, i, 1, MC_NORELOCATE );

            if ( !crs->success ){
                SIOSendString( "HECK" );
                //NewPrintf( "Error reading card %d, sector 0x%x\n", whichCard, i );
                QuickBlah_Hold( "\n\n\n\n\n\n        Error reading card %d, sector 0x%x\n", whichCard, i );
                goto readDone;
            }
            
            if ( i % 16 == 0 ){
                //NewPrintf( "Reading sector %d of %d (%d%%)\n", i, numSectors, ( i * 100 ) / numSectors );
                QuickBlah("\n\n\n\n\n\n        Reading sector %d of %d...\n", i, numSectors);                
            }

        }
        
        ClearTextBuffer();
        ClearBG();
        Blah( "\n\n\n\n\n\n        Sending to PC...\n");
        Draw();
        
        SIOSendString( "MCRD" );
        
        SendUlong( GPBUFFER );  // address to download from
        SendUlong( CARDSIZE );  // num bytes

        // nops will now issue a /DUMP command from this address
        
        readDone:
        
        
        InvalidateCards();
        Ack();
        return;
        

    }

    Ack();
}
*/
